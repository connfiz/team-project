# load-json-on-button-click


Code showing how to load a JSON file onto the page on the click of a button. Based on the project I posted on my code blog: http://www.femkreations.com/how-to-load-json-on-button-click/

For more blog posts visit: http://www.femkreations.com/blog/

Think your next project could benefit from my skills? Hire Me!

For more info visit: http://femKreations.com

Thanks Femy
